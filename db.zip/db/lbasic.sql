-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2021 at 12:49 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lbasic`
--

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `id` int(20) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`id`, `email`, `username`, `user_id`, `password`, `role`, `dob`, `phone`, `created_at`, `updated_at`) VALUES
(1, 'jetha@gadaelec.com', 'jethalal1', '1', NULL, NULL, NULL, NULL, NULL, '2021-04-14 11:36:54'),
(8, 'sunita@sabzi.com', 'sunita', '1', NULL, NULL, NULL, NULL, '2021-04-16 10:25:05', '2021-04-16 10:25:05'),
(9, 'mishty@gujela.com', 'mishty', '2', NULL, NULL, NULL, NULL, '2021-04-16 10:25:35', '2021-04-16 10:25:35'),
(10, 'gg@gmail.com', 'kkkk1', '1', NULL, NULL, NULL, NULL, '2021-04-16 10:35:20', '2021-04-16 10:41:25'),
(11, 'tt@llk.com', 'ii', '2', NULL, NULL, NULL, NULL, '2021-04-16 10:36:33', '2021-04-16 10:36:33'),
(12, 'loki@loyal.com', 'loki', '1', NULL, NULL, NULL, NULL, '2021-04-16 10:37:23', '2021-04-16 10:37:23'),
(13, '123', 'user', NULL, NULL, NULL, NULL, NULL, '2021-04-19 11:06:06', '2021-04-19 11:06:06'),
(14, 'rahulvermat006@gmail.com', 'Rahul Verma', NULL, '123', 'user', NULL, NULL, '2021-04-19 11:08:19', '2021-04-19 11:08:19'),
(15, 'ss', 'aa', NULL, '123', 'user', NULL, NULL, '2021-04-19 11:12:02', '2021-04-19 11:12:02'),
(16, 'ssss', 'aaaa', NULL, '123', 'user', NULL, NULL, '2021-04-19 12:47:03', '2021-04-19 12:47:03'),
(17, 'ee', 'aqq', NULL, '123', 'user', '2021-04-20', '08700729155', '2021-04-19 12:48:55', '2021-04-19 12:48:55'),
(18, 'Verma', 'Rahul', NULL, '123', 'Student', '2021-04-20', '08700729155', '2021-04-19 23:05:57', '2021-04-19 23:05:57'),
(19, NULL, NULL, '2', '123', 'Teacher', '2021-04-20', '1234567890', '2021-04-19 23:41:44', '2021-04-20 02:21:22'),
(20, 'first', 'last', '2', '123', 'Student', '2021-05-01', '0123456789', '2021-04-20 02:24:05', '2021-04-20 04:27:06');

-- --------------------------------------------------------

--
-- Table structure for table `details-draft`
--

CREATE TABLE `details-draft` (
  `id` int(20) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `details-draft`
--

INSERT INTO `details-draft` (`id`, `email`, `username`, `user_id`, `password`, `role`, `created_at`, `updated_at`) VALUES
(1, 'jetha@gadaelec.com', 'jethalal1', '1', NULL, NULL, NULL, '2021-04-14 11:36:54'),
(8, 'sunita@sabzi.com', 'sunita', '1', NULL, NULL, '2021-04-16 10:25:05', '2021-04-16 10:25:05'),
(9, 'mishty@gujela.com', 'mishty', '2', NULL, NULL, '2021-04-16 10:25:35', '2021-04-16 10:25:35'),
(10, 'gg@gmail.com', 'kkkk1', '1', NULL, NULL, '2021-04-16 10:35:20', '2021-04-16 10:41:25'),
(11, 'tt@llk.com', 'ii', '2', NULL, NULL, '2021-04-16 10:36:33', '2021-04-16 10:36:33'),
(12, 'loki@loyal.com', 'loki', '1', NULL, NULL, '2021-04-16 10:37:23', '2021-04-16 10:37:23'),
(13, '123', 'user', NULL, NULL, NULL, '2021-04-19 11:06:06', '2021-04-19 11:06:06'),
(14, 'rahulvermat006@gmail.com', 'Rahul Verma', NULL, '123', 'user', '2021-04-19 11:08:19', '2021-04-19 11:08:19');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_04_08_154142_create_details_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `dob`, `phone`, `created_at`, `updated_at`) VALUES
(1, 'test1', 'test@one.com', '$2y$10$WaPrILoAYFstw3AX5jGaJu0nvDwwn6ZQRMlWfHj2KKKghKaQQ0r/.', NULL, NULL, NULL, NULL, NULL),
(2, 'test2', 'test@two.com', '$2y$10$ZAsEC31zbhiz.7i2VsVPne/goaTnn85hXLRzWhn5fUmKvU6QO5CPS', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users1`
--

CREATE TABLE `users1` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users1`
--

INSERT INTO `users1` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'rahul', 'rahul@verma.com', '$2y$10$WaPrILoAYFstw3AX5jGaJu0nvDwwn6ZQRMlWfHj2KKKghKaQQ0r/.', NULL, NULL),
(2, 'tony', 'tony@stark.com', '$2y$10$ZAsEC31zbhiz.7i2VsVPne/goaTnn85hXLRzWhn5fUmKvU6QO5CPS', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `details`
--
ALTER TABLE `details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `details-draft`
--
ALTER TABLE `details-draft`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `users1`
--
ALTER TABLE `users1`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `details`
--
ALTER TABLE `details`
  MODIFY `id` int(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `details-draft`
--
ALTER TABLE `details-draft`
  MODIFY `id` int(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users1`
--
ALTER TABLE `users1`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
