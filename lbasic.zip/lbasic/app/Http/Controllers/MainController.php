<?php

namespace App\Http\Controllers;
//use App\Http\Controllers\DB;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\Detail;
use App\Models\User;
use Session;
//use Illuminate\Support\MessageBag;
class MainController extends Controller
{
    function index(){
		$userId=Session::get('id');//['id']; // taking user id 
		$details = DB::table('users')
		->join('details','users.id',"=",'details.user_id')
		->where('details.user_id',$userId)
		->get();
		
		return view('home',['details'=>$details]);
	}
	
	function add(){
		
		return view('add');
	}
	
	function insert(Request $req){
		
		
		$validated = $req->validate([
        'email' => 'required|email',
        'username' => 'required|',
    ]);
		//$errors = $validate->errors();
		$data=new Detail();
		
		$data->email=$req->email;
		$data->username=$req->username;
		$req->session()->flash('username', $req->username);
		$data->save();
		
		return redirect('/');
		
	}
	
	function edit($id){
		
		$data=Detail::find($id);
		return view('edit',['details'=>$data]);
	}
	
	function update(Request $req){
		$update= Detail::find($req->id);
		$update->email=$req->email;
		$update->username=$req->username;
		//$req->session()->flash('email',$req->email);

		$update->phone=$req->phone;
		$update->dob=$req->dob;

		$update->save();
		return redirect('home');
	}

	function delete(Request $req,$id){
		$data=Detail::find($id);
		$data->delete();
		$req->session()->flash('id', $id);
		return redirect('/');
	}

	function new_reg(){
	return view('new_reg');
	
	}


	function create(Request $req){
		
		
		//return "working";
		 $data=new Detail();
		
		 $data->email=$req->email;
		 $data->username=$req->name;
		 $data->password=$req->password;
		 $data->role=$req->role;
		 $data->user_id=$req->user_id;
		 $data->phone=$req->phone;
		 $data->dob=$req->dob;

		// //$req->session()->flash('username', $req->username);
		 $data->save();
		
		 return redirect('home');
		
	}

	function updatetwo(Request $req){
		$update= Detail::find($req->id);
		$update->email=$req->email;
		$update->username=$req->username;
		$data->role=$req->role;
		$data->user_id=$req->user_id;
		$data->phone=$req->phone;
		$data->dob=$req->dob;
		//$req->session()->flash('email',$req->email);
		$update->save();
		return redirect('/');
	}


}
