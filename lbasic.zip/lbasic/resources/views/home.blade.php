<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	
	
	<!-- Latest compiled and minified CSS
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	
</head>
<body>
	@include('header')
	<div class="container">

	

		<div class="row">
		<div class="col-sm-12">
			<a href="add">
			<input type="button" class="btn btn-primary pull-right" value="Add">
			</a>
			
			</div>
		
		</div>
	
<table class="table">
	<tr>
	<td>Id</td>
	<td>Email</td>
	<td>Username</td>
	<td>User Id</td>
	<td>Edit</td>
	<td>Delete</td>
	
	</tr>
	@foreach($details as $detail)
	<tr>
	
	<td>{{$detail->id}}</td>
	<td>{{$detail->email}}</td>
	<td>{{$detail->username}}</td>
	<td>{{$detail->user_id}}</td>
	<td><a href="edit/{{$detail->id}}">Edit</a></td>
	<td><a href="delete/{{$detail->id}}">Delete</a></td>
	
	</tr>
	@endforeach
	
	
	
	</table>	
		
		</div>
</body>
</html>