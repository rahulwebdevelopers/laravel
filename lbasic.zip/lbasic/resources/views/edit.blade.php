<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
@include('header')
		<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

	
	
</head>

<body>
	<div class="container">
	<form method="post" action="edit">
		@csrf
		
		<input type="hidden" name="id" value="{{$details['id']}}">
  <div class="form-group">
    <label for="exampleInputEmail1">First Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" value="{{$details['email']}}" placeholder="First Name">
   <span style="color:red">@error('email'){{$message}}@enderror</span>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Last Name</label>
    <input type="text" class="form-control" value="{{$details['username']}}" name="username" id="exampleInputPassword1" placeholder="Last Name">
	<span style="color:red">@error('username'){{$message}}@enderror</span>
  </div>


  <div class="form-group">
    <label for="exampleInputEmail1">Date of Birth</label>
    <input type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="dob" value="{{$details['dob']}}" >
   <span style="color:red">@error('email'){{$message}}@enderror</span>
  </div>


  <div class="form-group">
    <label for="exampleInputPassword1">Phone</label>
    <input type="text" class="form-control" value="{{$details['phone']}}" name="phone" id="exampleInputPassword1" placeholder="Phone">
	<span style="color:red">@error('username'){{$message}}@enderror</span>
  </div>
 
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
	
	</div>
</body>
</html>