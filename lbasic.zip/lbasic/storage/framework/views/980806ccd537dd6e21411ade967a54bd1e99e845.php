<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	
	
	<!-- Latest compiled and minified CSS
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	
</head>
<body>
	<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="container">

	

		<div class="row">
		<div class="col-sm-12">
			<a href="add">
			<input type="button" class="btn btn-primary pull-right" value="Add">
			</a>
			
			</div>
		
		</div>
	
<table class="table">
	<tr>
	<td>Id</td>
	<td>Email</td>
	<td>Username</td>
	<td>User Id</td>
	<td>Edit</td>
	<td>Delete</td>
	
	</tr>
	<?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
	
	<td><?php echo e($detail->id); ?></td>
	<td><?php echo e($detail->email); ?></td>
	<td><?php echo e($detail->username); ?></td>
	<td><?php echo e($detail->user_id); ?></td>
	<td><a href="edit/<?php echo e($detail->id); ?>">Edit</a></td>
	<td><a href="delete/<?php echo e($detail->id); ?>">Delete</a></td>
	
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
	
	
	</table>	
		
		</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\lbasic\resources\views/home.blade.php ENDPATH**/ ?>